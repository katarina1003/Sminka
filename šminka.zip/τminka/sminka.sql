-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 09, 2021 at 04:48 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sminka`
--

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `kategorijas`
--

CREATE TABLE `kategorijas` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `naziv` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `kategorijas`
--

INSERT INTO `kategorijas` (`id`, `naziv`) VALUES
(3, 'SMINKA ZA LICE'),
(4, 'SMINKA ZA OCI'),
(5, 'NOKTI'),
(6, 'NEGA LICA');

-- --------------------------------------------------------

--
-- Table structure for table `kupovinas`
--

CREATE TABLE `kupovinas` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `ime` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `prezime` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `adresa` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `grad` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `telefon` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `kupovinas`
--

INSERT INTO `kupovinas` (`id`, `ime`, `prezime`, `adresa`, `grad`, `email`, `telefon`) VALUES
(2, 'fasd', 'fsda', 'fsad', 'dfsa', 'sdfa', 'sdf'),
(3, 'pera', 'xzc', 'zxc', 'dfsa', 'xzc', 'zxc');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2021_02_08_212243_create_kategorijas', 1),
(5, '2021_02_08_212322_create_proizvods', 1),
(6, '2021_02_08_212511_alter_proizvods', 1),
(7, '2021_02_08_212555_create_kupovina', 1),
(8, '2021_02_08_212651_create_stavka', 1);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `proizvods`
--

CREATE TABLE `proizvods` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `naziv` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slika` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `opis` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cena` int(11) NOT NULL,
  `detalji` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nacin_upotrebe` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dejstvo` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sastav` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `kategorija_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `proizvods`
--

INSERT INTO `proizvods` (`id`, `naziv`, `slika`, `opis`, `cena`, `detalji`, `nacin_upotrebe`, `dejstvo`, `sastav`, `kategorija_id`) VALUES
(3, 'BOURJOIS HM COMPACT PUDER RLC 4', 'https://shop.lilly.rs/uploads/store/products/images/6020fa01db808.jpg', 'Kompaktni puder sa kompleksom vitamina', 1445, 'Za lice', 'Naneti na cisto lice', 'Neguje kožu i čini je lepšom', 'TALC, NYLON-12, OCTYLDODECYL STEAROYL STEARATE, KAOLIN, ISOSTEARYL NEOPENTANOATE, DIPHENYL DIMETHICO', 3),
(4, 'MAX FACTOR MIRACLE SECOND PUDER 07 NEUTRAL MEDIUM', 'https://shop.lilly.rs/uploads/store/products/images/x5ffd758d19328.jpg.pagespeed.ic.0z1QVFbOjd.webp', 'Miracle Second Skin, lagani fluid za usavršavanje kože koji je obnavlja, štiti i hidrira.', 1655, 'Tečni puder koji neguje vašu kožu. Obogaćen kokosovim mlekom,glicerinom a u njemu nećete naći parab', 'Naneti na cisto lice', 'Neguje kožu i čini je lepšom', 'TALC, NYLON-12, OCTYLDODECYL STEAROYL STEARATE, KAOLIN, ISOSTEARYL NEOPENTANOATE, DIPHENYL DIMETHICO', 3),
(5, 'LOREAL PARIS LASH PARADISE VALENTINES MASKARA', 'https://shop.lilly.rs/uploads/store/products/images/6007ea8757f34.jpg', 'Lash Paradise maskara limitirano izdanje. Novo limitirano pakovanje za dan zaljubljenih. Intenzivan volumen.', 1255, 'Za lice', 'Naneti na cisto lice', 'Neguje kožu i čini je lepšom', 'TALC, NYLON-12, OCTYLDODECYL STEAROYL STEARATE, KAOLIN, ISOSTEARYL NEOPENTANOATE, DIPHENYL DIMETHICO', 4),
(6, 'MAX FACTOR SOFT PALETA SENKI MISTY ONY 05', 'https://shop.lilly.rs/uploads/store/products/images/5fc4bb2935ca3.jpg', 'Predivna formula od pudera do kreme.', 1739, 'Za lice', 'Naneti na cisto lice', 'Neguje kožu i čini je lepšom', 'TALC, NYLON-12, OCTYLDODECYL STEAROYL STEARATE, KAOLIN, ISOSTEARYL NEOPENTANOATE, DIPHENYL DIMETHICO', 4),
(7, '21 LAK ZA NOKTE 72 DARK ROSE', 'https://shop.lilly.rs/uploads/store/products/images/5fe99b0b4977f.jpg', '21 Lak za nokte 72 nijansa Dark rose', 89, 'Za lice', 'Naneti na cisto lice', 'Neguje kožu i čini je lepšom', 'TALC, NYLON-12, OCTYLDODECYL STEAROYL STEARATE, KAOLIN, ISOSTEARYL NEOPENTANOATE, DIPHENYL DIMETHICO', 5),
(8, '21 LAK ZA NOKTE 71 TRAVA ZELENA', 'https://shop.lilly.rs/uploads/store/products/images/5fe99ad5e1ba6.jpg', '21 Lak za nokte 71 nijansa trava zelena', 89, 'Za lice', 'Naneti na cisto lice', 'Neguje kožu i čini je lepšom', 'TALC, NYLON-12, OCTYLDODECYL STEAROYL STEARATE, KAOLIN, ISOSTEARYL NEOPENTANOATE, DIPHENYL DIMETHICO', 5),
(9, 'EUCERIN HYALURON FILLER SKIN REFINER SERUM 30ML', 'https://shop.lilly.rs/uploads/store/products/images/601d0dec75df2.jpg', 'Izuzetno lagana I osvežavajuća gel formulacija koja pomaže u borbi sa prvim znacima starenja kože', 3250, 'Za lice', 'Naneti na cisto lice', 'Neguje kožu i čini je lepšom', 'TALC, NYLON-12, OCTYLDODECYL STEAROYL STEARATE, KAOLIN, ISOSTEARYL NEOPENTANOATE, DIPHENYL DIMETHICO', 6),
(10, 'EVELINE MAGIC SKIN CC ANTI-REDNESS 8IN1 KREMA 50ML', 'https://shop.lilly.rs/uploads/store/products/images/x6020fb8d70c70.jpg.pagespeed.ic.QzGuA2_5hi.webp', 'CC KREMA ZA LICE protiv crvenila na koži', 479, 'Za lice', 'Naneti na cisto lice', 'Neguje kožu i čini je lepšom', 'TALC, NYLON-12, OCTYLDODECYL STEAROYL STEARATE, KAOLIN, ISOSTEARYL NEOPENTANOATE, DIPHENYL DIMETHICO', 6);

-- --------------------------------------------------------

--
-- Table structure for table `stavkas`
--

CREATE TABLE `stavkas` (
  `kupovina_id` bigint(20) UNSIGNED NOT NULL,
  `proizvod_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `kategorijas`
--
ALTER TABLE `kategorijas`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `kupovinas`
--
ALTER TABLE `kupovinas`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `proizvods`
--
ALTER TABLE `proizvods`
  ADD PRIMARY KEY (`id`),
  ADD KEY `proizvods_kategorija_id_foreign` (`kategorija_id`);

--
-- Indexes for table `stavkas`
--
ALTER TABLE `stavkas`
  ADD KEY `stavkas_kupovina_id_foreign` (`kupovina_id`),
  ADD KEY `stavkas_proizvod_id_foreign` (`proizvod_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `kategorijas`
--
ALTER TABLE `kategorijas`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `kupovinas`
--
ALTER TABLE `kupovinas`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `proizvods`
--
ALTER TABLE `proizvods`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `proizvods`
--
ALTER TABLE `proizvods`
  ADD CONSTRAINT `proizvods_kategorija_id_foreign` FOREIGN KEY (`kategorija_id`) REFERENCES `kategorijas` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `stavkas`
--
ALTER TABLE `stavkas`
  ADD CONSTRAINT `stavkas_kupovina_id_foreign` FOREIGN KEY (`kupovina_id`) REFERENCES `kupovinas` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `stavkas_proizvod_id_foreign` FOREIGN KEY (`proizvod_id`) REFERENCES `proizvods` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
