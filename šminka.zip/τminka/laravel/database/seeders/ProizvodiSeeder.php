<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;


class ProizvodiSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('proizvods')->insert(
            [
                ['naziv' => 'BOURJOIS HM COMPACT PUDER RLC 4','opis' => 'Kompaktni puder sa kompleksom vitamina','slika' => 'https://shop.lilly.rs/uploads/store/products/images/6020fa01db808.jpg','cena' =>1445 ,'detalji' => 'Za lice','nacin_upotrebe' => 'Naneti na čisto lice','dejstvo'=>'Neguje kožu i čini je lepšom','sastav'=>'TALC, NYLON-12, OCTYLDODECYL STEAROYL STEARATE, KAOLIN, ISOSTEARYL NEOPENTANOATE, DIPHENYL DIMETHICO','kategorija_id'=>3],
                ['naziv' => 'MAX FACTOR MIRACLE SECOND PUDER 07 NEUTRAL MEDIUM','opis' => 'Miracle Second Skin, lagani fluid za usavršavanje kože koji je obnavlja, štiti i hidrira.','slika' => 'https://shop.lilly.rs/uploads/store/products/images/x5ffd758d19328.jpg.pagespeed.ic.0z1QVFbOjd.webp','cena' =>1655 ,'detalji' => 'Tečni puder koji neguje vašu kožu. Obogaćen kokosovim mlekom,glicerinom a u njemu nećete naći parab','nacin_upotrebe' => 'Naneti na čisto lice','dejstvo'=>'Neguje kožu i čini je lepšom','sastav'=>'TALC, NYLON-12, OCTYLDODECYL STEAROYL STEARATE, KAOLIN, ISOSTEARYL NEOPENTANOATE, DIPHENYL DIMETHICO','kategorija_id'=>3],
                ['naziv' => 'LOREAL PARIS LASH PARADISE VALENTINES MASKARA','opis' => 'Lash Paradise maskara limitirano izdanje. Novo limitirano pakovanje za dan zaljubljenih. Intenzivan volumen.','slika' => 'https://shop.lilly.rs/uploads/store/products/images/6007ea8757f34.jpg','cena' =>1255 ,'detalji' => 'Za lice','nacin_upotrebe' => 'Naneti na čisto lice','dejstvo'=>'Neguje kožu i čini je lepšom','sastav'=>'TALC, NYLON-12, OCTYLDODECYL STEAROYL STEARATE, KAOLIN, ISOSTEARYL NEOPENTANOATE, DIPHENYL DIMETHICO','kategorija_id'=>4],
                ['naziv' => 'MAX FACTOR SOFT PALETA SENKI MISTY ONY 05','opis' => 'Predivna formula od pudera do kreme.','slika' => 'https://shop.lilly.rs/uploads/store/products/images/5fc4bb2935ca3.jpg','cena' =>1739 ,'detalji' => 'Za lice','nacin_upotrebe' => 'Naneti na čisto lice','dejstvo'=>'Neguje kožu i čini je lepšom','sastav'=>'TALC, NYLON-12, OCTYLDODECYL STEAROYL STEARATE, KAOLIN, ISOSTEARYL NEOPENTANOATE, DIPHENYL DIMETHICO','kategorija_id'=>4],
                ['naziv' => '21 LAK ZA NOKTE 72 DARK ROSE','opis' => '21 Lak za nokte 72 nijansa Dark rose','slika' => 'https://shop.lilly.rs/uploads/store/products/images/5fe99b0b4977f.jpg','cena' =>89 ,'detalji' => 'Za lice','nacin_upotrebe' => 'Naneti na čisto lice','dejstvo'=>'Neguje kožu i čini je lepšom','sastav'=>'TALC, NYLON-12, OCTYLDODECYL STEAROYL STEARATE, KAOLIN, ISOSTEARYL NEOPENTANOATE, DIPHENYL DIMETHICO','kategorija_id'=>5],
                ['naziv' => '21 LAK ZA NOKTE 71 TRAVA ZELENA','opis' => '21 Lak za nokte 71 nijansa trava zelena','slika' => 'https://shop.lilly.rs/uploads/store/products/images/5fe99ad5e1ba6.jpg','cena' =>89 ,'detalji' => 'Za lice','nacin_upotrebe' => 'Naneti na čisto lice','dejstvo'=>'Neguje kožu i čini je lepšom','sastav'=>'TALC, NYLON-12, OCTYLDODECYL STEAROYL STEARATE, KAOLIN, ISOSTEARYL NEOPENTANOATE, DIPHENYL DIMETHICO','kategorija_id'=>5],
                ['naziv' => 'EUCERIN HYALURON FILLER SKIN REFINER SERUM 30ML','opis' => 'Izuzetno lagana I osvežavajuća gel formulacija koja pomaže u borbi sa prvim znacima starenja kože','slika' => 'https://shop.lilly.rs/uploads/store/products/images/601d0dec75df2.jpg','cena' =>3250 ,'detalji' => 'Za lice','nacin_upotrebe' => 'Naneti na čisto lice','dejstvo'=>'Neguje kožu i čini je lepšom','sastav'=>'TALC, NYLON-12, OCTYLDODECYL STEAROYL STEARATE, KAOLIN, ISOSTEARYL NEOPENTANOATE, DIPHENYL DIMETHICO','kategorija_id'=>6],
                ['naziv' => 'EVELINE MAGIC SKIN CC ANTI-REDNESS 8IN1 KREMA 50ML','opis' => 'CC KREMA ZA LICE protiv crvenila na koži','slika' => 'https://shop.lilly.rs/uploads/store/products/images/x6020fb8d70c70.jpg.pagespeed.ic.QzGuA2_5hi.webp','cena' =>479 ,'detalji' => 'Za lice','nacin_upotrebe' => 'Naneti na čisto lice','dejstvo'=>'Neguje kožu i čini je lepšom','sastav'=>'TALC, NYLON-12, OCTYLDODECYL STEAROYL STEARATE, KAOLIN, ISOSTEARYL NEOPENTANOATE, DIPHENYL DIMETHICO','kategorija_id'=>6],
            ]
        );
    }
}
