<?php $__env->startSection('title','Kategorije'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-sm-12 col-md-10 col-md-offset-1">
                <table class="table table-hover">
                    <thead>
                    <tr>
                        <th>Proizvod</th>
                        <th class="text-center">Cena</th>
                    </tr>
                    </thead>
                    <tbody>

                    <?php $__currentLoopData = $korpa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proizvod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="col-sm-8 col-md-6">
                                <div class="media">
                                    <a class="thumbnail pull-left" href="#"> <img class="media-object" src="<?php echo e($proizvod->slika); ?>" style="width: 72px; height: 72px;"> </a>
                                    <div class="media-body">
                                        <h4 class="media-heading"><a href="#"><?php echo e($proizvod->naziv); ?></a></h4>
                                    </div>
                                </div></td>
                            <td class="col-sm-1 col-md-1 text-center"><strong><?php echo e($proizvod->cena); ?> RSD</strong></td>
                        </tr>




                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    <form action="/kupi" method="post">
                    <td>
                            <?php echo e(csrf_field()); ?>

                            <input type="text" name="ime" placeholder="ime">
                            <br>
                            <input type="text" name="prezime" placeholder="prezime">
                            <br>
                            <input type="text" name="adresa" placeholder="adresa">
                            <br>
                            <input type="text" name="grad" placeholder="grad">
                            <br>
                            <input type="text" name="email" placeholder="email">
                            <br>
                            <input type="text" name="telefon" placeholder="telefon">

                       </td>
                    <td>   </td>
                    <td>   </td>
                    <td>
                        <a class="btn btn-default" href="http://127.0.0.1:8000/" role="button"> Nazad u prodavnicu</a>
                        </td>
                    <td>
                        <button type="submit" class="btn btn-success">
                            Kupi <span class="glyphicon glyphicon-play"></span>
                        </button></td>
                    </form>
                    </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Windows HD\Desktop 5\sminka\laravel\resources\views/korpa.blade.php ENDPATH**/ ?>