<?php $__env->startSection('title',$kategorija->naziv); ?>

<?php $__env->startSection('content'); ?>
    <div class="container mb-4">
        <div class="row">
    <?php $__currentLoopData = $kategorija->proizvodi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proizvod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-12 col-sm-12 col-md-6 col-lg-4 col-xl-4 mt-4">
            <div class="card shadow">
                <div class="card-body text-center">
                    <a href="<?php echo e($kategorija->id); ?>/<?php echo e($proizvod->id); ?>">
                        <img class="card-img-top" src="<?php echo e($proizvod->slika); ?>" alt="">
                    </a>
                    <div class="text-warning">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="far fa-star"></i>
                    </div>
                    <a href="{$kategorija->id}}/<?php echo e($proizvod->id); ?>"><h6 class="card-title"><?php echo e($proizvod->naziv); ?></h6></a>
                    <h6><?php echo e($proizvod->cena); ?> RSD </h6>
                    <a class="btn btn-dark my-2" href="<?php echo e($kategorija->id); ?>/<?php echo e($proizvod->id); ?>" role="button">Detalji</a>
                </div>
            </div>
        </div>
        <br>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Windows HD\Desktop 5\sminka\laravel\resources\views/kategorije.blade.php ENDPATH**/ ?>