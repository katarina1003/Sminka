<?php $__env->startSection('title','Sminka'); ?>

<?php $__env->startSection('content'); ?>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <a class="navbar-brand" href="#">Šminka</a>
        <div class="collapse navbar-collapse" id="navbarText">
            <ul class="navbar-nav mr-auto">
                <?php $__currentLoopData = $kategorije; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategorija): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="nav-item active">
                        <a class="nav-link" href="<?php echo e($kategorija->id); ?>"><?php echo e($kategorija->naziv); ?> </a>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <li class="nav-item active">
                        <a class="nav-link" href="/korpa">KORPA</a>
                    </li>
            </ul>

        </div>
    </nav>

    <div class="container mb-4">
        <div class="row">
            <?php $__currentLoopData = $kategorije; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategorija): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $__currentLoopData = $kategorija->proizvodi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proizvod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-12 col-sm-12 col-md-6 col-lg-4 col-xl-4 mt-4">
                        <div class="card shadow">
                            <div class="card-body text-center">
                                <a href="<?php echo e($kategorija->id); ?>/<?php echo e($proizvod->id); ?>">
                                    <img class="card-img-top" src="<?php echo e($proizvod->slika); ?>" alt="">
                                </a>
                                <div class="text-warning">
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="far fa-star"></i>
                                </div>
                                <a href="{$kategorija->id}}/<?php echo e($proizvod->id); ?>"><h6 class="card-title"><?php echo e($proizvod->naziv); ?></h6></a>
                                <h6><?php echo e($proizvod->cena); ?> RSD </h6>
                                <a class="btn btn-dark my-2" href="<?php echo e($kategorija->id); ?>/<?php echo e($proizvod->id); ?>" role="button">Detalji</a>
                            </div>
                        </div>
                    </div>
                    <br>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </div>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Korisnik\Desktop\laravel\resources\views/pocetna.blade.php ENDPATH**/ ?>