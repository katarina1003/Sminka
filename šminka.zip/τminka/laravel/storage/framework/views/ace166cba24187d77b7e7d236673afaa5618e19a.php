<?php $__env->startSection('title', 'Homepage'); ?>

<?php $__env->startSection('content'); ?>

<style>

table, th, td {
  border: solid 1px #000;
  padding: 10px;
}

table {
    border-collapse:collapse;
    caption-side:bottom;
}

.firstCol {
    background-color: lightgrey;
    font-size: 18px;
}

.caption {
    color: purple;
    font-size: 16px;
    transition: all 1s ease;
    padding: 15px;
}

.caption:hover {
    font-size: 20px;
    color:#4B0082;
}

.form-caption {
    font-size: 20px;
    color:#4B0082;
    padding-left: 44%;
}

.form-group {
    margin-top: 1px;
    margin-bottom: 1px;
}

input {
    height: 20px;
}

</style>

<div style="background-color:lightgrey; width: 22%; margin: 0 auto; height: 60px; text-align: center;  border-radius: 15px;
 margin-top: 30px;">
<p class="caption">Evidencija o pozajmljenim knjigama</p>
</div>

<table style="border: 1px solid black; margin: 0 auto; margin-top: 65px;">
    <tr class="firstCol">
        <td>Knjiga</td>
        <td>Autor</td>
        <td>Duguje</td>
    </tr>
    <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($message->title); ?></td>
        <td><?php echo e($message->content); ?></td>
        <td><?php echo e($message->author); ?></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</table>

<div class="form" style=" margin-top: 45px;">

<p class="form-caption">Dodaj u Evidenciju:</p>

<form action="/create" method="post" style="padding-left: 44%;">
    <div class="form-group">
        <input class="form-control" type="text" name="title" placeholder="title"/>
    </div>

    <div class="form-group">
        <input class="form-control" type="text" name="content" placeholder="author"/>
    </div>

    <div class="form-group">
        <input class="form-control" type="text" name="author" placeholder="person responsible"/>
    </div>
    <?php echo e(csrf_field()); ?>


    <div class="form-group">
        <button type="submit" style="width: 12.8em; margin-top: 5px">Add</button>
    </div>

</form>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Windows HD\Desktop 5\laravelProj\studentsdata\resources\views/home.blade.php ENDPATH**/ ?>