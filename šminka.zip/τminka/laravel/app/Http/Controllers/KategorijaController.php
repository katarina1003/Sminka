<?php

namespace App\Http\Controllers;

use App\Models\Kategorija;
use App\Models\Proizvod;
use Illuminate\Http\Request;

class KategorijaController extends Controller
{
    public function all(){
        $kategorije=Kategorija::all();
        $proizvodi=Proizvod::all();
        foreach ($kategorije as $kategorija) {
            $niz=[];
            foreach ($proizvodi as $proizvod) {
                if ($proizvod->kategorija_id == $kategorija->id){
                    $niz[count($niz)]=$proizvod;
                }
            }
            $kategorija->proizvodi=$niz;
        }

        return view('pocetna', [
            'kategorije'=>$kategorije
        ]);

    }
    public function view($id){
        $kategorija= Kategorija::findOrFail($id);
        $proizvodi=Proizvod::all();
        $niz=[];
        foreach ($proizvodi as $proizvod) {
            if ($proizvod->kategorija_id == $kategorija->id){
                $niz[count($niz)]=$proizvod;
            }
        }
        $kategorija->proizvodi=$niz;
        return view('kategorije',['kategorija'=>$kategorija]);

    }
    public function getAll(){
        $kategorije=Kategorija::all();
        $proizvodi=Proizvod::all();
        foreach ($kategorije as $kategorija) {
            $niz=[];
            foreach ($proizvodi as $proizvod) {
                if ($proizvod->kategorija_id == $kategorija->id){
                    $niz[count($niz)]=$proizvod;
                }
            }
            $kategorija->proizvodi=$niz;
        }

        return response()->json($kategorije,200);
    }
    public function getById($id){
        $kategorija=Kategorija::find($id);
        $proizvodi=Proizvod::all();
        if(is_null($kategorija)){
            return response()->json(["message"=>"Ne postoji kategorija"],404);
        }
        $niz=[];
        foreach ($proizvodi as $proizvod) {
            if ($proizvod->kategorija_id == $kategorija->id){
                $niz[count($niz)]=$proizvod;
            }
        }
        $kategorija->proizvodi=$niz;
        return response()->json($kategorija,200);
    }
}
