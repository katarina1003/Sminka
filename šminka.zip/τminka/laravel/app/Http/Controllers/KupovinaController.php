<?php

namespace App\Http\Controllers;

use App\Models\Kupovina;
use App\Models\Stavka;
use Illuminate\Http\Request;

class KupovinaController extends Controller
{
    public function create(Request $request)
    {
        $kupovina = new Kupovina();
        $kupovina->ime = $request->ime;
        $kupovina->prezime = $request->prezime;
        $kupovina->adresa = $request->adresa;
        $kupovina->grad = $request->grad;
        $kupovina->email = $request->email;
        $kupovina->telefon = $request->telefon;
        $kupovina->save();
        $korpa = [];
        if ($request->session()->has('korpa')) {
            $korpa = $request->session()->get('korpa');
        }
        foreach ($korpa as $elements) {
            foreach ($elements as $element) {
                $stavka = new Stavka();
                $stavka->kupovina_id = $kupovina->id;
                $stavka->proizvod_id = $element->id;
                $stavka->save();
            }
        }
        $request->session()->forget('korpa');
        return redirect('/');
    }
}
