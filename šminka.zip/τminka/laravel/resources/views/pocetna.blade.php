
@extends('master')

@section('title','Sminka')

@section('content')
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <a class="navbar-brand" href="#">Šminka</a>
        <div class="collapse navbar-collapse" id="navbarText">
            <ul class="navbar-nav mr-auto">
                @foreach($kategorije as $kategorija)
                    <li class="nav-item active">
                        <a class="nav-link" href="{{$kategorija->id}}">{{$kategorija->naziv}} </a>
                    </li>
                @endforeach
                    <li class="nav-item active">
                        <a class="nav-link" href="/korpa">KORPA</a>
                    </li>
            </ul>

        </div>
    </nav>

    <div class="container mb-4">
        <div class="row">
            @foreach($kategorije as $kategorija)
                @foreach($kategorija->proizvodi as $proizvod)
                    <div class="col-12 col-sm-12 col-md-6 col-lg-4 col-xl-4 mt-4">
                        <div class="card shadow">
                            <div class="card-body text-center">
                                <a href="{{$kategorija->id}}/{{$proizvod->id}}">
                                    <img class="card-img-top" src="{{$proizvod->slika}}" alt="">
                                </a>
                                <div class="text-warning">
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="far fa-star"></i>
                                </div>
                                <a href="{$kategorija->id}}/{{$proizvod->id}}"><h6 class="card-title">{{$proizvod->naziv}}</h6></a>
                                <h6>{{$proizvod->cena}} RSD </h6>
                                <a class="btn btn-dark my-2" href="{{$kategorija->id}}/{{$proizvod->id}}" role="button">Detalji</a>
                            </div>
                        </div>
                    </div>
                    <br>
                @endforeach

            @endforeach

        </div>
    </div>




@endsection
