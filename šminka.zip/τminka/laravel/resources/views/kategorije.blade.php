@extends('master')

@section('title',$kategorija->naziv)

@section('content')
    <div class="container mb-4">
        <div class="row">
    @foreach($kategorija->proizvodi as $proizvod)
        <div class="col-12 col-sm-12 col-md-6 col-lg-4 col-xl-4 mt-4">
            <div class="card shadow">
                <div class="card-body text-center">
                    <a href="{{$kategorija->id}}/{{$proizvod->id}}">
                        <img class="card-img-top" src="{{$proizvod->slika}}" alt="">
                    </a>
                    <div class="text-warning">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="far fa-star"></i>
                    </div>
                    <a href="{$kategorija->id}}/{{$proizvod->id}}"><h6 class="card-title">{{$proizvod->naziv}}</h6></a>
                    <h6>{{$proizvod->cena}} RSD </h6>
                    <a class="btn btn-dark my-2" href="{{$kategorija->id}}/{{$proizvod->id}}" role="button">Detalji</a>
                </div>
            </div>
        </div>
        <br>
    @endforeach
        </div>
    </div>
@endsection
