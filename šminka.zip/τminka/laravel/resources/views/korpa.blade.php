@extends('master')

@section('title','Kategorije')

@section('content')
    <div class="container">
        <div class="row">
            <div class="col-sm-12 col-md-10 col-md-offset-1">
                <table class="table table-hover">
                    <thead>
                    <tr>
                        <th>Proizvod</th>
                        <th class="text-center">Cena</th>
                    </tr>
                    </thead>
                    <tbody>

                    @foreach($korpa as $proizvod)
                        <tr>
                            <td class="col-sm-8 col-md-6">
                                <div class="media">
                                    <a class="thumbnail pull-left" href="#"> <img class="media-object" src="{{$proizvod->slika}}" style="width: 72px; height: 72px;"> </a>
                                    <div class="media-body">
                                        <h4 class="media-heading"><a href="#">{{$proizvod->naziv}}</a></h4>
                                    </div>
                                </div></td>
                            <td class="col-sm-1 col-md-1 text-center"><strong>{{$proizvod->cena}} RSD</strong></td>
                        </tr>

{{--                        <p>{{$proizvod['id']}}</p>--}}
{{--                        <p>{{$proizvod['naziv']}}</p>--}}
{{--                        <p>{{$proizvod['cena']}}</p>--}}
                    @endforeach


                    <form action="/kupi" method="post">
                    <td>
                            {{ csrf_field() }}
                            <input type="text" name="ime" placeholder="ime">
                            <br>
                            <input type="text" name="prezime" placeholder="prezime">
                            <br>
                            <input type="text" name="adresa" placeholder="adresa">
                            <br>
                            <input type="text" name="grad" placeholder="grad">
                            <br>
                            <input type="text" name="email" placeholder="email">
                            <br>
                            <input type="text" name="telefon" placeholder="telefon">
{{--                            <button type="submit">Save</button>--}}
                       </td>
                    <td>   </td>
                    <td>   </td>
                    <td>
                        <a class="btn btn-default" href="http://127.0.0.1:8000/" role="button"> Nazad u prodavnicu</a>
                        </td>
                    <td>
                        <button type="submit" class="btn btn-success">
                            Kupi <span class="glyphicon glyphicon-play"></span>
                        </button></td>
                    </form>
                    </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>


@endsection
